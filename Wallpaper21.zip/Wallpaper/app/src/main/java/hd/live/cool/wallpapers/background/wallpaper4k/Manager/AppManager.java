package hd.live.cool.wallpapers.background.wallpaper4k.Manager;

import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.RatingBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import hd.live.cool.wallpapers.background.wallpaper4k.Components.ProgressRound;
import hd.live.cool.wallpapers.background.wallpaper4k.R;


public  class AppManager {

    public static String SelectedLocation="Demo";
    private static ProgressRound progressBar;

    public static void changeActivity(Context context, Class<? extends Activity> targetActivity) {
        Intent intent = new Intent(context, targetActivity);
        context.startActivity(intent);
    }

    public static void FullScreen(AppCompatActivity context) {
        context.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    public static void ShareApplication(Context context){

        try {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, R.string.app_name);
            String shareMessage= "\nEnjoying "+R.string.app_name+" Share it with your friends and help them discover something amazing\n\n";
            shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + context.getPackageName() +"\n\n";
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
            context.startActivity(Intent.createChooser(shareIntent, "choose one"));
        } catch(Exception e) {
            //e.toString();
        }
    }

    public static void RateUs(Context context) {
        final Dialog dialog = new Dialog(context);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.rate_us_dialog);
        dialog.setCancelable(false);
        final RatingBar ratingBar = (RatingBar) dialog.findViewById(R.id.rating);
        dialog.findViewById(R.id.cancekl).setOnClickListener(new View.OnClickListener() { // from class: m.a.a.b.w
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.findViewById(R.id.submit).setOnClickListener(new View.OnClickListener() { // from class: m.a.a.b.c0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                launchMarket(context);
            }
        });
        dialog.show();
    }

    private static void launchMarket(Context context) {
        Uri uri = Uri.parse("market://details?id=" + context.getPackageName());
        Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
        try {
            context.startActivity(myAppLinkToMarket);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(context, " unable to find market app", Toast.LENGTH_LONG).show();
        }
    }

    public static void showProgress(Activity context) {
        try {
            if (context != null && progressBar == null) {
                progressBar = new ProgressRound(context);
                progressBar.setCancelable(false);
                progressBar.setCanceledOnTouchOutside(false);
                progressBar.getWindow().setDimAmount(0.0f);
                progressBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                progressBar.show();
                Log.e("error", "showSmallProgressDialog ");
            }
            Log.e("error", "showSmallProgressDialog wedwdwed" );
        } catch (Exception e) {
            Log.e("error", "showSmallProgressDialog " + e.toString());
        }
    }

    public static void hideProgress() {
        try {
            if (progressBar != null && progressBar.isShowing()) {
                progressBar.dismiss();
                progressBar = null;
            }
        } catch (Exception e) {
            Log.e("error", "hideSmallProgressDialog " + e.toString());
        }
    }

}
