// WallpaperRepository.kt
package hd.live.cool.wallpapers.background.wallpaper4k.Activities

import hd.live.cool.wallpapers.background.wallpaper4k.Model.Image

object WallpaperRepository {
    // Global wallpaper list
    val wallpaperList: ArrayList<Image> = ArrayList()

    // Method to add wallpapers to the global list
    fun addWallpapers(newWallpapers: List<Image>) {
        wallpaperList.addAll(newWallpapers)
    }

    // Method to get the wallpaper at a specific index
    fun getWallpaperAtIndex(index: Int): Image? {
        return if (index in wallpaperList.indices) wallpaperList[index] else null
    }
    fun clearWallpapers() {
        if (wallpaperList.isEmpty()) {
            wallpaperList.clear()
        }
    }
}
