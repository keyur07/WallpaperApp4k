package hd.live.cool.wallpapers.background.wallpaper4k.Adapter

import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import hd.live.cool.wallpapers.background.wallpaper4k.Activities.HDWallpaperActivity
import hd.live.cool.wallpapers.background.wallpaper4k.Model.Image
import hd.live.cool.wallpapers.background.wallpaper4k.R

class FavoriteAdapter(
    private val context: Context,
    private val wallpaperList: List<Image.FavImages>, // Generic list of wallpapers
    private val name: String // Used for passing additional info
) : RecyclerView.Adapter<FavoriteAdapter.ViewHolder>() {

    companion object {
        var selectedWallpaperUrl: String? = null // For passing selected wallpaper
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val image: ImageView = view.findViewById(R.id.image)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.view_wallpaper_list, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val wallpaper = wallpaperList[position]

        // Load the wallpaper thumbnail using Glide
        Log.e("mmmmmmmmm",wallpaper.thumbM)
        Glide.with(holder.itemView)
            .load(wallpaper.thumbM) // Assuming `thumbM` contains the URL for the thumbnail
            .into(holder.image)
Log.e("Wallpaper uri",wallpaper.thumbM)
        // Handle click event
        holder.itemView.setOnClickListener {
            selectedWallpaperUrl = wallpaper.thumbM

            val favoriteUrls = wallpaperList.map { it.thumbM } // Get URLs of all favorites
            val intent = Intent(context, HDWallpaperActivity::class.java)
            intent.putExtra("Name", "Favorites")
            intent.putExtra("Position",position)
            intent.putStringArrayListExtra("FavoriteList", ArrayList(favoriteUrls)) // Pass the list
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return wallpaperList.size
    }
}
