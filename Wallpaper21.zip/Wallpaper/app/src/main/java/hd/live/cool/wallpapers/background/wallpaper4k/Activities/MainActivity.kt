package hd.live.cool.wallpapers.background.wallpaper4k.Activities

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.graphics.drawable.DrawerArrowDrawable
import androidx.core.content.ContextCompat
import hd.live.cool.wallpapers.background.wallpaper4k.Adapter.CustomPagerAdapter
import hd.live.cool.wallpapers.background.wallpaper4k.Manager.MyUtility.Companion.ChangeStatusbarAndBottomColor
import hd.live.cool.wallpapers.background.wallpaper4k.R
import hd.live.cool.wallpapers.background.wallpaper4k.databinding.ActivityMainBinding
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var actionBarDrawerToggle: ActionBarDrawerToggle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        init()
    }

    @SuppressLint("ResourceAsColor")
    private fun init() {
        ChangeStatusbarAndBottomColor(this)
        actionBarDrawerToggle = ActionBarDrawerToggle(
            this,
            binding.myDrawerLayout,
            binding.toolbarMain,
            R.string.nav_open,
            R.string.nav_close
        )
        binding.myDrawerLayout.addDrawerListener(actionBarDrawerToggle)
        actionBarDrawerToggle.syncState()
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val drawerArrowDrawable = DrawerArrowDrawable(this)
        drawerArrowDrawable.color = ContextCompat.getColor(this, R.color.white)
        actionBarDrawerToggle.drawerArrowDrawable = drawerArrowDrawable


        val viewPagerAdapter = CustomPagerAdapter(supportFragmentManager)
        binding.mainFragment.adapter = viewPagerAdapter

        binding.tabLayout.setupWithViewPager(binding.mainFragment)

        binding.navigationBar.setNavigationItemSelectedListener(NavigationView.OnNavigationItemSelectedListener { item ->
            val itemId = item.itemId
            if (itemId == R.id.share_app) {
                hd.live.cool.wallpapers.background.wallpaper4k.Manager.AppManager.ShareApplication(this@MainActivity)
            } else if (itemId == R.id.rate_app) {
                hd.live.cool.wallpapers.background.wallpaper4k.Manager.AppManager.RateUs(this@MainActivity)
            } else if (itemId == R.id.contactus) {
               // AppManager.changeActivity(this@MainActivity, ContactUs::class.java)
                Toast.makeText(this,"THis Feature is not available right now!",Toast.LENGTH_SHORT).show()
            }
            true
        })


    }




}