package hd.live.cool.wallpapers.background.wallpaper4k.Adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import hd.live.cool.wallpapers.background.wallpaper4k.Model.Image
import hd.live.cool.wallpapers.background.wallpaper4k.databinding.ActivityHdwallpaperBinding
import hd.live.cool.wallpapers.background.wallpaper4k.databinding.ImageLayoutBinding // Use the generated binding class

class HavenViewPager(
    private val wallpapers: List<Image>,
    private val binding: ActivityHdwallpaperBinding,
    private val onWallpaperClick: (Image) -> Unit
) : RecyclerView.Adapter<HavenViewPager.WallpaperViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WallpaperViewHolder {
        val itemBinding = ImageLayoutBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return WallpaperViewHolder(itemBinding)
    }

    override fun onBindViewHolder(holder: WallpaperViewHolder, position: Int) {
        val wallpaper = wallpapers[position]
        Log.e("message", wallpaper.thumbM)

        // Load the thumbnail image using Glide (thumbM URL)
        val thumbnailUrl = getThumbnailUrl(wallpaper.picid)
        Glide.with(holder.itemView.context)
            .load(thumbnailUrl)  // Load the modified thumbnail URL
            .into(holder.binding.imageView)

        // Handle click on an item to show the full-size image
        holder.itemView.setOnClickListener {
            // Get the full-size image URL
            val fullSizeUrl = getThumbnailUrl(wallpaper.picid)

            // Pass the full-size URL to the callback
            onWallpaperClick(wallpaper)

            // Show full-size image in ViewPager
            binding.mainParent.visibility = View.GONE
            binding.fullParent.visibility = View.VISIBLE
            Glide.with(holder.itemView.context)
                .load(fullSizeUrl)  // Load the full-size URL
                .into(binding.fullsizeimage)
        }
    }

    override fun getItemCount(): Int = wallpapers.size

    // ViewHolder to hold the views for each wallpaper item
    inner class WallpaperViewHolder(val binding: ImageLayoutBinding) :
        RecyclerView.ViewHolder(binding.root)

    // Function to get the thumbnail URL
    private fun getThumbnailUrl(picId: String): String {
        return "https://images.hdqwalls.com/portrait/1080/$picId.jpg"
    }

}
