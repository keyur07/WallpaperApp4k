package hd.live.cool.wallpapers.background.wallpaper4k.Adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import hd.live.cool.wallpapers.background.wallpaper4k.Activities.WallpaperActivity
import hd.live.cool.wallpapers.background.wallpaper4k.Model.Category
import hd.live.cool.wallpapers.background.wallpaper4k.R

class FullHDWallsAdapter(var context: Context, var category: List<Category>?) :RecyclerView.Adapter<FullHDWallsAdapter.Viewholder>(){


    inner class Viewholder(v : View): RecyclerView.ViewHolder(v){
        var image = v.findViewById<ImageView>(R.id.image)
        var title = v.findViewById<TextView>(R.id.category)
    }

    companion object{
        lateinit var cat: List<String>
        var pos:Int =17;
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): FullHDWallsAdapter.Viewholder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.fullhdview,parent,false)
        return Viewholder(view)
    }

    override fun onBindViewHolder(holder: FullHDWallsAdapter.Viewholder, position: Int) {
        Glide.with(holder.itemView).load(category?.get(position)?.Full_HD?.get(0)).into(holder.image)
        holder.title.text = category?.get(position)?.name?.toUpperCase()

        holder.itemView.setOnClickListener{
            pos= position;
            cat = category!!.get(position).Full_HD
            val intent = Intent(context, WallpaperActivity::class.java)
            intent.putExtra("catgory",category?.get(position)?.name)
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return category!!.count()
    }
}
