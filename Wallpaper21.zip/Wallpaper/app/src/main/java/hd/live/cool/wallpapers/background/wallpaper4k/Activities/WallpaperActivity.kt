package hd.live.cool.wallpapers.background.wallpaper4k.Activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import hd.live.cool.wallpapers.background.wallpaper4k.Adapter.WallsAdapter
import hd.live.cool.wallpapers.background.wallpaper4k.Manager.MyUtility
import hd.live.cool.wallpapers.background.wallpaper4k.Model.UHDModel3
import hd.live.cool.wallpapers.background.wallpaper4k.Service.RetrofitClient
import hd.live.cool.wallpapers.background.wallpaper4k.databinding.ActivityWallpaperBinding
import retrofit2.Callback
import retrofit2.Response

class WallpaperActivity : AppCompatActivity() {
    private lateinit var binding: ActivityWallpaperBinding
    private lateinit var adapter : WallsAdapter
private lateinit var  Name:String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWallpaperBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbarMain)
        Name = intent.getStringExtra("catgory").toString().substring(0, 1)
            .uppercase() + intent.getStringExtra("catgory").toString().substring(1).toString()
        binding.name.text = intent.getStringExtra("catgory").toString().substring(0, 1).uppercase() + intent.getStringExtra("catgory").toString().substring(1)
        MyUtility.ChangeStatusbarAndBottomColor(this@WallpaperActivity)
        getWallpaperList()

        binding.backbtn.setOnClickListener({
            finish()
        })

    }

    private fun getWallpaperList() {
        val apiInterface = RetrofitClient.getRetrofitInstance().create(hd.live.cool.wallpapers.background.wallpaper4k.Interface.ApiInterface::class.java)
        val call = apiInterface.GetThumbWallpaperList()

        call.enqueue(object : Callback<UHDModel3> {
            override fun onResponse(call: retrofit2.Call<UHDModel3>, response: Response<UHDModel3>) {
                val layoutmanager = GridLayoutManager(MainActivity(),3)
                binding.listofwalls.layoutManager = layoutmanager
                adapter = WallsAdapter(this@WallpaperActivity, response.body()?.category,Name)
                binding.listofwalls.adapter = adapter
            }
            override fun onFailure(call: retrofit2.Call<UHDModel3>, t: Throwable) {
                Toast.makeText(MainActivity(),"Failed", Toast.LENGTH_LONG)
            }

        })
    }
}