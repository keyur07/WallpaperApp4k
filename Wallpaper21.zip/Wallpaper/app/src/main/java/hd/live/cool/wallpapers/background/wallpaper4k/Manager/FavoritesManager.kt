package hd.live.cool.wallpapers.background.wallpaper4k.Manager

import android.content.Context
import android.content.SharedPreferences

class FavoritesManager(context: Context) {
    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences("Favorites", Context.MODE_PRIVATE)

    // Add a favorite
    fun addFavorite(item: String) {
        val favorites = getFavorites().toMutableSet()
        favorites.add(item)
        sharedPreferences.edit().putStringSet("favorites", favorites).apply()
    }

    // Remove a favorite
    fun removeFavorite(item: String) {
        val favorites = getFavorites().toMutableSet()
        favorites.remove(item)
        sharedPreferences.edit().putStringSet("favorites", favorites).apply()
    }

    // Get all favorites
    fun getFavorites(): Set<String> {
        return sharedPreferences.getStringSet("favorites", emptySet()) ?: emptySet()
    }

    // Check if an item is a favorite
    fun isFavorite(item: String): Boolean {
        return getFavorites().contains(item)
    }
}
