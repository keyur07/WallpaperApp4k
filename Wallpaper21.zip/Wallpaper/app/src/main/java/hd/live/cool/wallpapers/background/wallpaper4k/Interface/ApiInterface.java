package hd.live.cool.wallpapers.background.wallpaper4k.Interface;

import hd.live.cool.wallpapers.background.wallpaper4k.Model.Model;
import hd.live.cool.wallpapers.background.wallpaper4k.Model.UHDModel;
import hd.live.cool.wallpapers.background.wallpaper4k.Model.UHDModel3;
import hd.live.cool.wallpapers.background.wallpaper4k.Model.WallpaperResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiInterface {

    @GET("7a7bce3cb67d5c347ba3")
    Call<Model> GetWallpaperList();

    @GET("ddfa3382cd87279cdfcd")
    Call<UHDModel> GetUHDWallpaperList();

    @GET("a6461dbaa9920b18bd99")
    Call<UHDModel3> GetThumbWallpaperList();

    @GET("public/api5?req=images&records=50&order_by=Latest")
    Call<WallpaperResponse> getLatestWallpapers(@Query("page") int page);

    @GET("public/api5?req=images&records=50&order_by=Popular")
    Call<WallpaperResponse> getPopularWallpapers(@Query("page") int page);

    @GET("public/api5?req=images&records=50&order_by=Random")
    Call<WallpaperResponse> getRandomWallpapers(@Query("page") int page);



}
