package hd.live.cool.wallpapers.background.wallpaper4k.Adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import hd.live.cool.wallpapers.background.wallpaper4k.databinding.ActivityHdwallpaperBinding
import hd.live.cool.wallpapers.background.wallpaper4k.databinding.ImageLayoutBinding // Use the generated binding class

class ViewPagerAdapter(
    private val wallpapers: List<String>,
    val binding: ActivityHdwallpaperBinding,
    private val onWallpaperClick: (String) -> Unit
) : RecyclerView.Adapter<ViewPagerAdapter.WallpaperViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WallpaperViewHolder {
        // Inflate the layout using ViewBinding
        val binding = ImageLayoutBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return WallpaperViewHolder(binding)
    }

    override fun onBindViewHolder(holder: WallpaperViewHolder, position: Int) {
        val wallpaperUrl = wallpapers[position]

        // Load the wallpaper image using Glide
        Glide.with(holder.itemView.context)
            .load(wallpaperUrl)
            .into(holder.binding.imageView)

        // Handle click on an item
        holder.itemView.setOnClickListener {
            onWallpaperClick(wallpaperUrl)
        }
        holder.binding.imageView.setOnClickListener({
            binding.mainParent.visibility = View.GONE
            binding.fullParent.visibility = View.VISIBLE
            Glide.with(holder.itemView.context)
                .load(wallpaperUrl)
                .into(binding.fullsizeimage)

        })
    }

    override fun getItemCount(): Int = wallpapers.size

    // ViewHolder to hold the views for each wallpaper item
    inner class WallpaperViewHolder(val binding: ImageLayoutBinding) : RecyclerView.ViewHolder(binding.root)
}
