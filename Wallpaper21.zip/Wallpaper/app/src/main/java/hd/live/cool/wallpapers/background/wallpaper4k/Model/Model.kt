package hd.live.cool.wallpapers.background.wallpaper4k.Model

data class Model(  val category: List<Category>)

data class Category(
    val name: String,
    val Full_HD: List<String>,
)

