package hd.live.cool.wallpapers.background.wallpaper4k.Activities

import android.Manifest
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.app.WallpaperManager
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.CompositePageTransformer
import androidx.viewpager2.widget.MarginPageTransformer
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import hd.live.cool.wallpapers.background.wallpaper4k.Adapter.HavenViewPager
import hd.live.cool.wallpapers.background.wallpaper4k.Manager.FavoritesManager
import hd.live.cool.wallpapers.background.wallpaper4k.Model.Image
import hd.live.cool.wallpapers.background.wallpaper4k.R
import hd.live.cool.wallpapers.background.wallpaper4k.databinding.ActivityHdwallpaperBinding
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar
import hd.live.cool.wallpapers.background.wallpaper4k.Manager.AppManager
import jp.wasabeef.glide.transformations.BlurTransformation
import java.io.IOException
import kotlin.math.abs

class HDHavenWallpaper : AppCompatActivity() {
    private lateinit var binding: ActivityHdwallpaperBinding
    private var currentPage = 1
    private val wallpapersPerPage = 50 // Number of wallpapers per page
    private var isLoading = false
    private var selectedWallpaperIndex = 0
    private var wallpaperList: ArrayList<Image> = ArrayList()
    private lateinit var category: String
    private val REQUEST_CODE_PERMISSIONS = 1001

    private val baseUrl = "https://images.hdqwalls.com/portrait/1080/"
    private val imageFormat = ".jpg"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHdwallpaperBinding.inflate(layoutInflater)
        setContentView(binding.root)
        // Retrieve data from intent
        selectedWallpaperIndex = intent.getIntExtra("selectedIndex", 0)
        wallpaperList = intent.getParcelableArrayListExtra("wallpaperList") ?: ArrayList()
        category = intent.getStringExtra("category") ?: "Latest"

        binding.toolbar.name.text = category.toString()
        binding.toolbar.backbtn.setOnClickListener { finish() }

        setupViewPager()
        setupBottomSheetActions()

        binding.fullsizeimage.setOnClickListener {
            binding.mainParent.visibility = View.VISIBLE
            binding.fullParent.visibility = View.GONE
        }
    }

    private fun setupBottomSheetActions() {
        binding.bottomViewBtn.fabSetAction.setOnClickListener {
            val bottomSheetDialog = BottomSheetDialog(this, R.style.BottomSheetDialog)
            val bottom = LayoutInflater.from(this).inflate(R.layout.dialog_set_action, null)
            bottomSheetDialog.setContentView(bottom)
            bottomSheetDialog.show()

            setupBottomSheetClickListeners(bottomSheetDialog, bottom)
        }
    }

    private fun hasStoragePermissions(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    }


    private fun requestStoragePermissions() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
            REQUEST_CODE_PERMISSIONS
        )
    }


    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                saveWallpaper(null) // Retry saving after permission is granted
            } else {
                showSnackBar("Storage permission is required to save wallpapers.")
            }
        }
    }



    private fun saveWallpaper(bottomSheetDialog: BottomSheetDialog?) {
        try {
            val bitmap = (binding.fullsizeimage.drawable as BitmapDrawable).bitmap
            val resolver = contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "Wallpaper_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Wallpapers")
            }

            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            uri?.let {
                resolver.openOutputStream(it)?.use { outputStream ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
                    showSnackBar("Wallpaper saved successfully!")
                    AppManager.hideProgress()
                }
            }

            bottomSheetDialog?.dismiss()
        } catch (e: IOException) {
            e.printStackTrace()
            showSnackBar("Failed to save wallpaper!")
        }
    }



    private fun setupBottomSheetClickListeners(bottomSheetDialog: BottomSheetDialog, bottom: View) {
        bottom.findViewById<LinearLayout>(R.id.btn_set_home_screen).setOnClickListener {
            setWallpaperForScreen(bottomSheetDialog, WallpaperManager.FLAG_SYSTEM)
        }

        bottom.findViewById<LinearLayout>(R.id.btn_set_lock_screen).setOnClickListener {
            setWallpaperForScreen(bottomSheetDialog, WallpaperManager.FLAG_LOCK)
        }

        bottom.findViewById<LinearLayout>(R.id.btn_set_both).setOnClickListener {
            setWallpaperForScreen(bottomSheetDialog, null) // Set both screens
        }

        bottom.findViewById<LinearLayout>(R.id.btn_set_save).setOnClickListener {
            if (hasStoragePermissions()) {
                AppManager.showProgress(this@HDHavenWallpaper)
                saveWallpaper(bottomSheetDialog)
            } else {
                requestStoragePermissions()
            }
        }
    }

    private fun setWallpaperForScreen(bottomSheetDialog: BottomSheetDialog, flag: Int?) {
        AppManager.showProgress(this@HDHavenWallpaper)
        val imageUrl = getFullSizeImageUrl(wallpaperList[selectedWallpaperIndex].picid)
        Glide.with(this)
            .asBitmap()
            .load(imageUrl)
            .into(object : CustomTarget<Bitmap>() {
                @SuppressLint("ObsoleteSdkInt")
                override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                    try {
                        val wallpaperManager = WallpaperManager.getInstance(applicationContext)

                        if (flag != null) {
                            wallpaperManager.setBitmap(resource, null, true, flag)
                        } else {
                            wallpaperManager.setBitmap(resource)
                        }

                        showSnackBar("Wallpaper Updated")
                        bottomSheetDialog.dismiss()
                        AppManager.hideProgress()
                    } catch (e: IOException) {
                        e.printStackTrace()
                        showSnackBar("Wallpaper failed to update")
                        bottomSheetDialog.dismiss()
                        AppManager.hideProgress()
                    }
                }

                override fun onLoadCleared(placeholder: Drawable?) {
                    // Handle cleanup if needed
                }
            })
    }



    private fun fetchWallpapers(page: Int) {
        if (isLoading) return // Prevent multiple simultaneous fetches
        isLoading = true

        // Simulate an API call or database query
        val newWallpapers = mutableListOf<Image>() // Replace with API/database results
        for (i in 1..wallpapersPerPage) {
            newWallpapers.add(Image("wallpaper_${page}_$i", "Wallpaper $i"))
        }

        // Update the wallpaper list
        if (page > currentPage) {
            wallpaperList.addAll(newWallpapers) // Add to the end
        } else if (page < currentPage) {
            wallpaperList.addAll(0, newWallpapers) // Add to the beginning
        }

        currentPage = page
        binding.viewpager.adapter?.notifyDataSetChanged()
        isLoading = false
    }


    private fun setupViewPager() {
        if (wallpaperList.isEmpty()) {
            Toast.makeText(this, "No wallpapers available", Toast.LENGTH_SHORT).show()
            return
        }

        val viewPagerAdapter = HavenViewPager(wallpaperList, binding) { selectedImage ->
            val imageUrl = getFullSizeImageUrl(selectedImage.picid)
            setBackgroundImage(imageUrl)
        }
        binding.viewpager.adapter = viewPagerAdapter

        val displayMetrics = DisplayMetrics()
        window.windowManager.defaultDisplay.getMetrics(displayMetrics)
        val paddingToSet = displayMetrics.widthPixels / 10
        binding.viewpager.setPadding(paddingToSet, 0, paddingToSet, 40)

        binding.viewpager.clipToPadding = false
        binding.viewpager.clipChildren = false
        binding.viewpager.offscreenPageLimit = 3
        binding.viewpager.getChildAt(0).overScrollMode = RecyclerView.OVER_SCROLL_NEVER

        val compositePageTransformer = CompositePageTransformer()
        compositePageTransformer.addTransformer(MarginPageTransformer(40))
        compositePageTransformer.addTransformer { page, position ->
            val scale = 1 - abs(position)
            page.scaleY = 0.85f + scale * 0.15f
        }
        binding.viewpager.setPageTransformer(compositePageTransformer)

        binding.viewpager.setCurrentItem(selectedWallpaperIndex, false)
        val initialImageUrl = getFullSizeImageUrl(wallpaperList[selectedWallpaperIndex].picid)
        setBackgroundImage(initialImageUrl)

        binding.viewpager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                selectedWallpaperIndex = position
                val imageUrl = getFullSizeImageUrl(wallpaperList[position].picid)
                setBackgroundImage(imageUrl)
                val favoritesManager = FavoritesManager(this@HDHavenWallpaper)

                if (favoritesManager.isFavorite(imageUrl)) {
                    binding.bottomViewBtn.btnFavorite.setImageResource(R.drawable.ic_action_fav) // "Favorite" image
                } else {
                    binding.bottomViewBtn.btnFavorite.setImageResource(R.drawable.ic_action_fav_outline) // "Not favorite" image
                }

                if (position == wallpaperList.size - 1) fetchWallpapers(currentPage + 1)
                if (position == 0 && currentPage > 1) fetchWallpapers(currentPage - 1)
            }
        })

        binding.bottomViewBtn.btnDownload.setOnClickListener {
            val downloadUrl = getFullSizeImageUrl(wallpaperList[selectedWallpaperIndex].picid)
            downloadWallpaper(downloadUrl)
        }

        binding.bottomViewBtn.btnFavorite.setOnClickListener {
            val favoritesManager = FavoritesManager(this)
            val imageUrl = getFullSizeImageUrl(wallpaperList[selectedWallpaperIndex].picid)

            if (favoritesManager.isFavorite(imageUrl)) {
                favoritesManager.removeFavorite(imageUrl)
                binding.bottomViewBtn.btnFavorite.setImageResource(R.drawable.ic_action_fav_outline)
                showSnackBar("Removed from favorites")
            } else {
                favoritesManager.addFavorite(imageUrl)
                binding.bottomViewBtn.btnFavorite.setImageResource(R.drawable.ic_action_fav)
                showSnackBar("Added to favorites")
            }
        }
    }

    private fun getFullSizeImageUrl(picid: String): String {
        return "$baseUrl$picid$imageFormat"
    }

    private fun setBackgroundImage(imageUrl: String) {
        Glide.with(this)
            .load(imageUrl)
            .transform(BlurTransformation(100, 3))
            .into(object : CustomTarget<Drawable>() {
                override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable>?) {
                    binding.mainBackground.background = resource
                    val fadeIn = ObjectAnimator.ofFloat(binding.mainBackground, View.ALPHA, 0.6f, 1.0f)
                    fadeIn.duration = 500
                    fadeIn.start()
                }

                override fun onLoadCleared(placeholder: Drawable?) {
                    // Handle cleanup if needed
                }
            })
    }

    private fun downloadWallpaper(imageUrl: String) {
        Glide.with(this)
            .asBitmap()
            .load(imageUrl)
            .into(object : CustomTarget<Bitmap>() {
                override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                    try {
                        val contentResolver = applicationContext.contentResolver
                        val values = ContentValues().apply {
                            put(MediaStore.Images.Media.DISPLAY_NAME, "Wallpaper_${System.currentTimeMillis()}.jpg")
                            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Wallpapers")
                        }

                        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                        uri?.let {
                            contentResolver.openOutputStream(it)?.use { outputStream ->
                                resource.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
                                showSnackBar("Wallpaper Downloaded Successfully")
                            }
                        }
                    } catch (e: IOException) {
                        e.printStackTrace()
                        showSnackBar("Failed to Save Wallpaper")
                    }
                }

                override fun onLoadCleared(placeholder: Drawable?) {
                    // Handle cleanup if needed
                }
            })
    }

    private fun showSnackBar(message: String) {
        Snackbar.make(binding.mainBackground, message, Snackbar.LENGTH_SHORT).show()
    }
}

