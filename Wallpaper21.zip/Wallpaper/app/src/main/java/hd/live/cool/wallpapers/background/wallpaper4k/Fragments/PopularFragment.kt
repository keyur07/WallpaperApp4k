package hd.live.cool.wallpapers.background.wallpaper4k.Fragments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import hd.live.cool.wallpapers.background.wallpaper4k.Adapter.WallhavenAdapter
import hd.live.cool.wallpapers.background.wallpaper4k.Model.Image
import hd.live.cool.wallpapers.background.wallpaper4k.Model.WallpaperResponse
import hd.live.cool.wallpapers.background.wallpaper4k.Service.RetrofitClient
import hd.live.cool.wallpapers.background.wallpaper4k.databinding.FragmentPopularBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
class PopularFragment : Fragment() {
    private lateinit var binding: FragmentPopularBinding
    private var adapter: WallhavenAdapter? = null
    private val popularWallpaperList: ArrayList<Image> = ArrayList() // Local list for popular wallpapers
    private var currentPage = 1
    private val totalPages = 50
    private var isLoading = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentPopularBinding.inflate(inflater, container, false)
        setupRecyclerView()

        binding.listofwalls.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)

                val layoutManager = recyclerView.layoutManager as GridLayoutManager?
                if (layoutManager != null && !isLoading && currentPage <= totalPages) {
                    val visibleItemCount = layoutManager.childCount
                    val totalItemCount = layoutManager.itemCount
                    val firstVisibleItemPosition = layoutManager.findFirstVisibleItemPosition()

                    if (firstVisibleItemPosition + visibleItemCount >= totalItemCount && firstVisibleItemPosition >= 0) {
                        currentPage++
                        getWallpaperList(currentPage)
                    }
                }
            }
        })
        return binding.root
    }

    private fun getWallpaperList(page: Int) {
        isLoading = true
        val apiInterface = RetrofitClient.getRetrofitInstance_second().create(hd.live.cool.wallpapers.background.wallpaper4k.Interface.ApiInterface::class.java)
        val call = apiInterface.getPopularWallpapers(page)

        call.enqueue(object : Callback<WallpaperResponse?> {
            override fun onResponse(call: Call<WallpaperResponse?>, response: Response<WallpaperResponse?>) {
                if (response.isSuccessful && response.body() != null) {
                    val newWallpapers = response.body()!!.images
                    popularWallpaperList.addAll(newWallpapers) // Add to the local list
                    adapter!!.notifyDataSetChanged()
                } else {
                    Toast.makeText(requireContext(), "No data available", Toast.LENGTH_SHORT).show()
                }
                isLoading = false
            }

            override fun onFailure(call: Call<WallpaperResponse?>, t: Throwable) {
                Toast.makeText(requireContext(), "Failed: ${t.message}", Toast.LENGTH_LONG).show()
                Log.e("Error", t.message!!)
                isLoading = false
            }
        })
    }

    private fun setupRecyclerView() {
        val layoutManager = GridLayoutManager(requireContext(), 3)
        binding.listofwalls.layoutManager = layoutManager
        adapter = WallhavenAdapter(requireContext(), popularWallpaperList, "Popular") // Use the local list
        binding.listofwalls.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        popularWallpaperList.clear() // Clear only the local list
        getWallpaperList(currentPage)
    }
}
