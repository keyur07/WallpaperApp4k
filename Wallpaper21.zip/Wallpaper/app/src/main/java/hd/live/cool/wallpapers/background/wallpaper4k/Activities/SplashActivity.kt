package hd.live.cool.wallpapers.background.wallpaper4k.Activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.bumptech.glide.Glide
import hd.live.cool.wallpapers.background.wallpaper4k.Model.Image
import hd.live.cool.wallpapers.background.wallpaper4k.databinding.ActivitySplashBinding

class SplashActivity : AppCompatActivity() {

    private lateinit var binding : ActivitySplashBinding
    companion object{
        var iswallpapertype = 0;
        val wallpaperList: ArrayList<Image> = ArrayList()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)
        Glide.with(this)
            .load("https://images.hdqwalls.com/portrait/1080/185908.jpg")
            .into(binding.background)
        init()

    }

    private fun init(){
        val handler = Handler(Looper.getMainLooper())
        handler.postDelayed({
            startActivity(Intent(this,MainActivity::class.java))
        }, 3000);
    }
}