package hd.live.cool.wallpapers.background.wallpaper4k.Manager

import android.app.Activity
import android.view.WindowManager
import androidx.core.content.ContextCompat
import hd.live.cool.wallpapers.background.wallpaper4k.R

class MyUtility {
    companion object {

        fun FullScreen(context: Activity) {
            val window = context.window
            window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN)
        }

        fun ChangeStatusbarAndBottomColor(context : Activity){
            val window = context.window
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.statusBarColor = ContextCompat.getColor(context, R.color.main)
            context.window.navigationBarColor = ContextCompat.getColor(context,R.color.main)

        }



    }
}