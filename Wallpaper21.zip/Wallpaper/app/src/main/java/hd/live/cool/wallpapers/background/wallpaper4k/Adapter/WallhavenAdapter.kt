package hd.live.cool.wallpapers.background.wallpaper4k.Adapter

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieAnimationView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import hd.live.cool.wallpapers.background.wallpaper4k.Model.Image
import hd.live.cool.wallpapers.background.wallpaper4k.R

class WallhavenAdapter(
    private val context: Context,
    private val wallpaperList: List<Image>?,
    private val s: String,
) : RecyclerView.Adapter<WallhavenAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val image: ImageView = view.findViewById(R.id.image)
        val progressLoader: LottieAnimationView = view.findViewById(R.id.progress_loader)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.view_wallpaper_list, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentImage = wallpaperList?.get(position)

        // Show loader before loading
        holder.progressLoader.visibility = View.VISIBLE

        Glide.with(holder.itemView)
            .load("https://images.hdqwalls.com/portrait/720/" + currentImage?.picid + ".jpg")
            .transition(DrawableTransitionOptions.withCrossFade(500)) // Fade-in animation
            .listener(object : RequestListener<Drawable> {
                override fun onLoadFailed(
                    e: GlideException?,
                    model: Any?,
                    target: Target<Drawable>,
                    isFirstResource: Boolean
                ): Boolean {
                    // Hide the loader if loading fails
                    holder.progressLoader.visibility = View.GONE
                    return false
                }

                override fun onResourceReady(
                    resource: Drawable,
                    model: Any,
                    target: Target<Drawable>?,
                    dataSource: DataSource,
                    isFirstResource: Boolean
                ): Boolean {
                    // Hide the loader when the image is successfully loaded
                    holder.progressLoader.visibility = View.GONE
                    return false
                }
            })
            .into(holder.image)

        // Handle item click
        holder.itemView.setOnClickListener {
            val intent = Intent(context, hd.live.cool.wallpapers.background.wallpaper4k.Activities.HDHavenWallpaper::class.java)
            intent.putParcelableArrayListExtra("wallpaperList", ArrayList(wallpaperList ?: emptyList()))
            intent.putExtra("selectedIndex", position)
            intent.putExtra("category", s)
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int = wallpaperList?.size ?: 0
}
