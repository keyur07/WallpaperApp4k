package hd.live.cool.wallpapers.background.wallpaper4k.Model

data class UHDModel(val category: List<Category2>)
data class Category2(
    val UHD: List<String>,
    val name: String,
)

data class UHDModel3(val category: List<Category3>)
data class Category3(
    val thumb: List<String>,
    val name: String,
)