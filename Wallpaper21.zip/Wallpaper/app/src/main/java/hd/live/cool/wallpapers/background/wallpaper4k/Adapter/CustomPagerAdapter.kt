package hd.live.cool.wallpapers.background.wallpaper4k.Adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import hd.live.cool.wallpapers.background.wallpaper4k.Fragments.Category
import hd.live.cool.wallpapers.background.wallpaper4k.Fragments.Dashboard
import hd.live.cool.wallpapers.background.wallpaper4k.Fragments.LatestFragment
import hd.live.cool.wallpapers.background.wallpaper4k.Fragments.PopularFragment
import hd.live.cool.wallpapers.background.wallpaper4k.Fragments.RandomFragment

class CustomPagerAdapter(fm: FragmentManager) : FragmentPagerAdapter(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {

    override fun getItem(position: Int): Fragment {
        return when (position) {

            0 -> RandomFragment()
            1 -> LatestFragment()
            2 -> PopularFragment()
            3 -> Category()
            4 -> Dashboard()

            else -> throw IllegalArgumentException("Invalid position")
        }
    }

    override fun getCount(): Int {
        return 5
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return when (position) {
            0 -> "RANDOM"
            1 -> "LATEST"
            2 -> "POPULAR"
            3 -> "CATEGORY"
            4 -> "FAVORITE"
            else -> null
        }
    }
}
