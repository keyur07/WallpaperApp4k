package hd.live.cool.wallpapers.background.wallpaper4k.Fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import hd.live.cool.wallpapers.background.wallpaper4k.Activities.SplashActivity
import hd.live.cool.wallpapers.background.wallpaper4k.Adapter.FullHDWallsAdapter
import hd.live.cool.wallpapers.background.wallpaper4k.Model.Model
import hd.live.cool.wallpapers.background.wallpaper4k.Service.RetrofitClient
import hd.live.cool.wallpapers.background.wallpaper4k.databinding.FragmentCategoryBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Category : Fragment() {

    private lateinit var binding: FragmentCategoryBinding
    private lateinit var adapter: FullHDWallsAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout using ViewBinding
        binding = FragmentCategoryBinding.inflate(inflater, container, false)
SplashActivity.iswallpapertype =0;
        // Initialize the RecyclerView and fetch wallpapers
        setupRecyclerView()
        getWallpaperList()

        return binding.root
    }

    private fun setupRecyclerView() {
        // Set up GridLayoutManager for RecyclerView
        val layoutManager = GridLayoutManager(requireContext(), 1)
        binding.listofwalls.layoutManager = layoutManager
    }

    private fun getWallpaperList() {
        val apiInterface = RetrofitClient.getRetrofitInstance().create(hd.live.cool.wallpapers.background.wallpaper4k.Interface.ApiInterface::class.java)
        val call = apiInterface.GetWallpaperList()

        call.enqueue(object : Callback<Model> {
            override fun onResponse(call: Call<Model>, response: Response<Model>) {
                if (response.isSuccessful && response.body() != null) {
                    // Initialize and set the adapter
                    val categoryList = response.body()?.category
                    adapter = FullHDWallsAdapter(requireContext(), categoryList)
                    binding.listofwalls.adapter = adapter
                } else {
                    Toast.makeText(requireContext(), "No data available", Toast.LENGTH_LONG).show()
                }
            }

            override fun onFailure(call: Call<Model>, t: Throwable) {
                Toast.makeText(requireContext(), "Failed: ${t.message}", Toast.LENGTH_LONG).show()
            }
        })
    }
}
