package hd.live.cool.wallpapers.background.wallpaper4k.Activities

import android.annotation.SuppressLint
import android.app.WallpaperManager
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.CompositePageTransformer
import androidx.viewpager2.widget.MarginPageTransformer
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import hd.live.cool.wallpapers.background.wallpaper4k.Adapter.ViewPagerAdapter
import hd.live.cool.wallpapers.background.wallpaper4k.Adapter.WallsAdapter
import hd.live.cool.wallpapers.background.wallpaper4k.Manager.FavoritesManager
import hd.live.cool.wallpapers.background.wallpaper4k.Model.UHDModel
import hd.live.cool.wallpapers.background.wallpaper4k.R
import hd.live.cool.wallpapers.background.wallpaper4k.Service.RetrofitClient
import hd.live.cool.wallpapers.background.wallpaper4k.databinding.ActivityHdwallpaperBinding
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar
import jp.wasabeef.glide.transformations.BlurTransformation
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.IOException
import kotlin.math.abs

class HDWallpaperActivity : AppCompatActivity() {

    private lateinit var wallList: List<String>
    private lateinit var binding: ActivityHdwallpaperBinding
    private var url = "https://mrprofootball.com/images/UHD/ocean143.jpg"
    private val REQUEST_CODE_PERMISSIONS = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHdwallpaperBinding.inflate(layoutInflater)
        setContentView(binding.root)

        WallsAdapter.selectedWallpaper = intent.getIntExtra("Position",0)

        if(intent.getStringExtra("Name").equals("Favorites")) {
            val favoriteList = intent.getStringArrayListExtra("FavoriteList") ?: arrayListOf()
            if (favoriteList.isNotEmpty()) {
                setupViewPager(favoriteList)
                setBackgroundImage(favoriteList[intent.getIntExtra("Position", 2)]) // Set the first wallpaper as background
            } else {
                Toast.makeText(this, "No favorites found", Toast.LENGTH_LONG).show()
            }
        } else {
            getUHDWallpaper()
        }

        binding.fullsizeimage.setOnClickListener {
            binding.mainParent.visibility = View.VISIBLE
            binding.fullParent.visibility = View.GONE
        }
        binding.toolbar.name.text = intent.getStringExtra("Name")
        binding.toolbar.backbtn.setOnClickListener { finish() }

        setupBottomSheetActions()
    }

    private fun getUHDWallpaper() {
        val apiInterface = RetrofitClient.getRetrofitInstance().create(hd.live.cool.wallpapers.background.wallpaper4k.Interface.ApiInterface::class.java)
        val call = apiInterface.GetUHDWallpaperList()

        call.enqueue(object : Callback<UHDModel> {
            override fun onResponse(call: Call<UHDModel>, response: Response<UHDModel>) {
                val categories = response.body()?.category
                if (categories != null && categories.isNotEmpty()) {
                    val selectedCategory = WallsAdapter.selectedWallpaperCategory
                    wallList = categories[selectedCategory].UHD

                    if (wallList.isNotEmpty()) {
                        setupViewPager(wallList)
                        setBackgroundImage(wallList[WallsAdapter.selectedWallpaper])
                    } else {
                        Toast.makeText(this@HDWallpaperActivity, "No wallpapers available", Toast.LENGTH_LONG).show()
                    }
                } else {
                    Toast.makeText(this@HDWallpaperActivity, "Failed to fetch wallpapers", Toast.LENGTH_LONG).show()
                }
            }

            override fun onFailure(call: Call<UHDModel>, t: Throwable) {
                Toast.makeText(this@HDWallpaperActivity, "Failed to fetch wallpapers", Toast.LENGTH_LONG).show()
            }
        })

        binding.bottomViewBtn.btnDownload.setOnClickListener {
            downloadWallpaper(url)
        }
    }

    private fun setupViewPager(wallpapers: List<String>) {
        val viewPagerAdapter = ViewPagerAdapter(wallpapers, binding) { selectedImage ->
            setBackgroundImage(selectedImage)
        }

        binding.viewpager.adapter = viewPagerAdapter

        val displayMetrics = DisplayMetrics()
        window.windowManager.defaultDisplay.getMetrics(displayMetrics)
        val paddingToSet = displayMetrics.widthPixels / 10
        binding.viewpager.setPadding(paddingToSet, 0, paddingToSet, 40)

        binding.viewpager.clipToPadding = false
        binding.viewpager.clipChildren = false
        binding.viewpager.offscreenPageLimit = 3
        binding.viewpager.getChildAt(0).overScrollMode = RecyclerView.OVER_SCROLL_NEVER

        val compositePageTransformer = CompositePageTransformer()
        compositePageTransformer.addTransformer(MarginPageTransformer(40))
        compositePageTransformer.addTransformer { page, position ->
            val scale = 1 - abs(position)
            page.scaleY = 0.85f + scale * 0.15f
        }
        binding.viewpager.setPageTransformer(compositePageTransformer)

//        binding.viewpager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
//            override fun onPageSelected(position: Int) {
//                super.onPageSelected(position)
//                WallsAdapter.selectedWallpaper = position
//                setBackgroundImage(wallpapers[position])
//            }
//        })

        binding.viewpager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                WallsAdapter.selectedWallpaper = position
                val imageUrl = wallpapers[position]
                setBackgroundImage(imageUrl)
                val favoritesManager = FavoritesManager(this@HDWallpaperActivity)

                if (favoritesManager.isFavorite(imageUrl)) {
                    binding.bottomViewBtn.btnFavorite.setImageResource(R.drawable.ic_action_fav) // "Favorite" image
                } else {
                    binding.bottomViewBtn.btnFavorite.setImageResource(R.drawable.ic_action_fav_outline) // "Not favorite" image
                }
            }
        })

        binding.viewpager.post {
            val selectedPosition = intent.getIntExtra("Position", 0)
            if (selectedPosition in wallpapers.indices) {
                binding.viewpager.setCurrentItem(selectedPosition, false)
            } else {
                binding.viewpager.setCurrentItem(0, false)
            }
        }


        binding.bottomViewBtn.btnFavorite.setOnClickListener {
            val favoritesManager = FavoritesManager(this)
            val imageUrl = wallpapers[WallsAdapter.selectedWallpaper]
Log.e("mmmmmmmmm",imageUrl)
            if (favoritesManager.isFavorite(imageUrl)) {
                favoritesManager.removeFavorite(imageUrl)
                binding.bottomViewBtn.btnFavorite.setImageResource(R.drawable.ic_action_fav_outline)
                showSnackBar("Removed from favorites")
            } else {
                favoritesManager.addFavorite(imageUrl)
                binding.bottomViewBtn.btnFavorite.setImageResource(R.drawable.ic_action_fav)
                showSnackBar("Added to favorites")
            }
        }
    }

    private fun setBackgroundImage(imageUrl: String) {
        url = imageUrl
        Glide.with(this)
            .load(imageUrl)
            .transform(BlurTransformation(100, 3)) // Apply blur effect
            .into(object : CustomTarget<Drawable>() {
                override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable>?) {
                    binding.mainBackground.background = resource
                }

                override fun onLoadCleared(placeholder: Drawable?) {}
            })
    }

    private fun setupBottomSheetActions() {
        binding.bottomViewBtn.fabSetAction.setOnClickListener {
            val bottomSheetDialog = BottomSheetDialog(this, R.style.BottomSheetDialog)
            val bottom = LayoutInflater.from(this).inflate(R.layout.dialog_set_action, null)
            bottomSheetDialog.setContentView(bottom)
            bottomSheetDialog.show()

            setupBottomSheetClickListeners(bottomSheetDialog, bottom)
        }
    }

    private fun setupBottomSheetClickListeners(bottomSheetDialog: BottomSheetDialog, bottom: View) {
        bottom.findViewById<LinearLayout>(R.id.btn_set_home_screen).setOnClickListener {
            setWallpaperForScreen(bottomSheetDialog, WallpaperManager.FLAG_SYSTEM)
        }

        bottom.findViewById<LinearLayout>(R.id.btn_set_lock_screen).setOnClickListener {
            setWallpaperForScreen(bottomSheetDialog, WallpaperManager.FLAG_LOCK)
        }

        bottom.findViewById<LinearLayout>(R.id.btn_set_both).setOnClickListener {
            setWallpaperForScreen(bottomSheetDialog, null) // Set both screens
        }

        bottom.findViewById<LinearLayout>(R.id.btn_set_save).setOnClickListener {
            if (hasStoragePermissions()) {
                saveWallpaper(bottomSheetDialog)
            } else {
                requestStoragePermissions()
            }
        }
    }

    private fun setWallpaperForScreen(bottomSheetDialog: BottomSheetDialog, flag: Int?) {
        Glide.with(this)
            .asBitmap()
            .load(url)
            .into(object : CustomTarget<Bitmap>() {
                @SuppressLint("ObsoleteSdkInt")
                override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                    try {
                        val wallpaperManager = WallpaperManager.getInstance(applicationContext)

                        if (flag != null) {
                            wallpaperManager.setBitmap(resource, null, true, flag)
                        } else {
                            wallpaperManager.setBitmap(resource)
                        }
                        showSnackBar("Wallpaper Updated")
                        bottomSheetDialog.dismiss()
                    } catch (e: IOException) {
                        e.printStackTrace()
                        showSnackBar("Wallpaper failed to update")
                        bottomSheetDialog.dismiss()
                    }
                }

                override fun onLoadCleared(placeholder: Drawable?) {}
            })
    }

    private fun showSnackBar(message: String) {
        Snackbar.make(binding.mainBackground, message, Snackbar.LENGTH_SHORT).show()
    }

    private fun downloadWallpaper(imageUrl: String) {
        Glide.with(this)
            .asBitmap()
            .load(imageUrl)
            .into(object : CustomTarget<Bitmap>() {
                override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                    try {
                        val contentResolver = applicationContext.contentResolver
                        val values = ContentValues().apply {
                            put(MediaStore.Images.Media.DISPLAY_NAME, "Wallpaper_${System.currentTimeMillis()}.jpg")
                            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Wallpapers")
                        }

                        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                        uri?.let {
                            contentResolver.openOutputStream(it)?.use { outputStream ->
                                resource.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
                                showSnackBar("Wallpaper Downloaded Successfully")
                            }
                        }
                    } catch (e: IOException) {
                        e.printStackTrace()
                        showSnackBar("Failed to Save Wallpaper")
                    }
                }

                override fun onLoadCleared(placeholder: Drawable?) {}
            })
    }

    private fun saveWallpaper(bottomSheetDialog: BottomSheetDialog) {
        Glide.with(this)
            .asBitmap()
            .load(getFullSizeImageUrl(url))
            .into(object : CustomTarget<Bitmap>() {
                override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                    try {
                        val contentResolver = applicationContext.contentResolver
                        val values = ContentValues().apply {
                            put(MediaStore.Images.Media.DISPLAY_NAME, "Wallpaper_${System.currentTimeMillis()}.jpg")
                            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Wallpapers")
                        }

                        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                        uri?.let {
                            contentResolver.openOutputStream(it)?.use { outputStream ->
                                resource.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
                                showSnackBar("Wallpaper Saved")
                                bottomSheetDialog.dismiss()
                            }
                        }
                    } catch (e: IOException) {
                        e.printStackTrace()
                        showSnackBar("Failed to Save Wallpaper")
                    }
                }

                override fun onLoadCleared(placeholder: Drawable?) {}
            })
    }

    private fun getFullSizeImageUrl(thumbUrl: String): String {
        val imageName = thumbUrl.substringAfterLast("/").substringBeforeLast(".")
        return "https://images.hdqwalls.com/download/$imageName-1080x2340.jpg"
    }

    private fun hasStoragePermissions(): Boolean {
        val permissionWrite = ContextCompat.checkSelfPermission(
            this,
            android.Manifest.permission.WRITE_EXTERNAL_STORAGE
        )
        val permissionRead = ContextCompat.checkSelfPermission(
            this,
            android.Manifest.permission.READ_EXTERNAL_STORAGE
        )

        return permissionWrite == PackageManager.PERMISSION_GRANTED &&
                permissionRead == PackageManager.PERMISSION_GRANTED
    }

    private fun requestStoragePermissions() {
        val permissionsToRequest = mutableListOf<String>()

        if (ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }

        if (ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.READ_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(android.Manifest.permission.READ_EXTERNAL_STORAGE)
        }

        // For Android 11 and above, request manage external storage permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                permissionsToRequest.add(android.Manifest.permission.MANAGE_EXTERNAL_STORAGE)
            }
        }

        if (permissionsToRequest.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                this,
                permissionsToRequest.toTypedArray(),
                REQUEST_CODE_PERMISSIONS
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }
}
