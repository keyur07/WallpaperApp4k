// LatestFragment.kt
package hd.live.cool.wallpapers.background.wallpaper4k.Fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import hd.live.cool.wallpapers.background.wallpaper4k.Adapter.WallhavenAdapter
import hd.live.cool.wallpapers.background.wallpaper4k.Model.Image
import hd.live.cool.wallpapers.background.wallpaper4k.Model.WallpaperResponse
import hd.live.cool.wallpapers.background.wallpaper4k.Service.RetrofitClient
import hd.live.cool.wallpapers.background.wallpaper4k.databinding.FragmentLatestBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LatestFragment : Fragment() {
    private var binding: FragmentLatestBinding? = null
    private var adapter: WallhavenAdapter? = null
    private val latestWallpaperList: ArrayList<Image> = ArrayList() // Local list for latest wallpapers
    private var currentPage = 1
    private val totalPages = 50 // You may need to adjust this based on your API's response
    private var isLoading = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        binding = FragmentLatestBinding.inflate(inflater, container, false)
        setupRecyclerView()

        // Pagination handling for infinite scrolling
        binding!!.listofwalls.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)

                val layoutManager = recyclerView.layoutManager as GridLayoutManager?
                if (layoutManager != null && !isLoading && currentPage <= totalPages) {
                    val visibleItemCount = layoutManager.childCount
                    val totalItemCount = layoutManager.itemCount
                    val firstVisibleItemPosition = layoutManager.findFirstVisibleItemPosition()

                    if (firstVisibleItemPosition + visibleItemCount >= totalItemCount && firstVisibleItemPosition >= 0) {
                        currentPage++
                        getWallpaperList(currentPage) // Fetch the next page
                    }
                }
            }
        })

        return binding!!.root
    }

    // Function to get wallpapers from the API
    private fun getWallpaperList(page: Int) {
        isLoading = true
        val apiInterface = RetrofitClient.getRetrofitInstance_second().create(hd.live.cool.wallpapers.background.wallpaper4k.Interface.ApiInterface::class.java)
        val call = apiInterface.getLatestWallpapers(page)

        call.enqueue(object : Callback<WallpaperResponse?> {
            override fun onResponse(call: Call<WallpaperResponse?>, response: Response<WallpaperResponse?>) {
                if (response.isSuccessful && response.body() != null) {
                    val newWallpapers = response.body()!!.images
                    latestWallpaperList.addAll(newWallpapers) // Add to the local list
                    adapter!!.notifyDataSetChanged() // Notify the adapter for the new data
                } else {
                    Toast.makeText(requireContext(), "No data available", Toast.LENGTH_SHORT).show()
                }
                isLoading = false
            }

            override fun onFailure(call: Call<WallpaperResponse?>, t: Throwable) {
                Toast.makeText(requireContext(), "Failed: ${t.message}", Toast.LENGTH_LONG).show()
                Log.e("Error", t.message!!)
                isLoading = false
            }
        })
    }

    // Setup RecyclerView with GridLayoutManager and adapter
    private fun setupRecyclerView() {
        val layoutManager = GridLayoutManager(requireContext(), 3) // 3 columns in GridLayout
        binding!!.listofwalls.layoutManager = layoutManager
        adapter = WallhavenAdapter(requireContext(), latestWallpaperList,"Latest") // Use the local list
        binding!!.listofwalls.adapter = adapter
    }

    // Refresh the list when the fragment is resumed
    override fun onResume() {
        super.onResume()
        latestWallpaperList.clear() // Clear the local list to avoid redundant data
        currentPage = 1 // Reset to the first page
        getWallpaperList(currentPage) // Fetch the first page of wallpapers
    }
}
