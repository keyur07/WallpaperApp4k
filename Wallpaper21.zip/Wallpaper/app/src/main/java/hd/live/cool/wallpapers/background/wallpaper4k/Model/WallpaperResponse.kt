package hd.live.cool.wallpapers.background.wallpaper4k.Model

import android.os.Parcel
import android.os.Parcelable

// Model class for API response
data class WallpaperResponse(
    val status: Int,
    val images: List<Image>
)

data class Image(
    val picid: String,
    val thumbM: String
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString() ?: "",
        parcel.readString() ?: ""
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(picid)
        parcel.writeString(thumbM)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Image> {
        override fun createFromParcel(parcel: Parcel): Image {
            return Image(parcel)
        }

        override fun newArray(size: Int): Array<Image?> {
            return arrayOfNulls(size)
        }
    }

    data class FavImages(
        val thumbM: String // URL of the thumbnail
    )
}

