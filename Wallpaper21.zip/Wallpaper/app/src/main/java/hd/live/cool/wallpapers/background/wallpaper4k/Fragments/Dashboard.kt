package hd.live.cool.wallpapers.background.wallpaper4k.Fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import hd.live.cool.wallpapers.background.wallpaper4k.Adapter.FavoriteAdapter
import hd.live.cool.wallpapers.background.wallpaper4k.Manager.FavoritesManager
import hd.live.cool.wallpapers.background.wallpaper4k.Model.Image
import hd.live.cool.wallpapers.background.wallpaper4k.databinding.FragmentDashboardBinding

class Dashboard : Fragment() {

    private lateinit var binding: FragmentDashboardBinding
    private lateinit var adapter: FavoriteAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentDashboardBinding.inflate(inflater, container, false)

        setupRecyclerView()
        loadFavorites() // Load and display favorites

        return binding.root
    }

    private fun setupRecyclerView() {
        val layoutManager = GridLayoutManager(requireContext(), 3)
        binding.listofwallpapers.layoutManager = layoutManager
    }

    private fun loadFavorites() {
        val favoritesManager = FavoritesManager(requireContext())
        val favoriteUrls = favoritesManager.getFavorites() // Retrieve favorite URLs

        if (favoriteUrls.isEmpty()) {
            Toast.makeText(requireContext(), "No favorites added", Toast.LENGTH_SHORT).show()
            return
        }

        // Convert favorite URLs into Image models (if needed)
        val favoriteImages = favoriteUrls.map { url -> Image.FavImages(thumbM = url) }

        // Pass favorite images to adapter
        adapter = FavoriteAdapter(requireContext(), favoriteImages, "Favorites")
        binding.listofwallpapers.adapter = adapter
    }
}
