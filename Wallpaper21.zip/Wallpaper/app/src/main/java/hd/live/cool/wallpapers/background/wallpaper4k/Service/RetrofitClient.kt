package hd.live.cool.wallpapers.background.wallpaper4k.Service

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class RetrofitClient {
    companion object{
        public lateinit var retrofit: Retrofit
        public val BASE_URL = "https://api.npoint.io/"
        public val BASE_URL_SECOND = "http://wallpapershaven.com/"


        fun getRetrofitInstance():Retrofit{

            val interceptor = HttpLoggingInterceptor()
            interceptor.level = HttpLoggingInterceptor.Level.BODY

            val client = OkHttpClient.Builder()
                .addInterceptor(interceptor)
                .build()

            val gson: Gson = GsonBuilder()
                .setLenient() // Set leniency here
                .create()

            val retrofit = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson)) // Pass the Gson instance
                .client(client)
                .build()

            return retrofit
        }

        fun getRetrofitInstance_second():Retrofit{

            val interceptor = HttpLoggingInterceptor()
            interceptor.level = HttpLoggingInterceptor.Level.BODY

            val client = OkHttpClient.Builder()
                .addInterceptor(interceptor)
                .build()

            val gson: Gson = GsonBuilder()
                .setLenient() // Set leniency here
                .create()

            val retrofit = Retrofit.Builder()
                .baseUrl(BASE_URL_SECOND)
                .addConverterFactory(GsonConverterFactory.create(gson)) // Pass the Gson instance
                .client(client)
                .build()

            return retrofit
        }
    }
}